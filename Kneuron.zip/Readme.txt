
** Tippy Blocker Extension **

Description:

This is a Chrome/Edge extension that has been developed by Normand Defayette of Cortex R&D Inc. 

The purpose is to remove those black pesky popups that keep blocking our view in Knack's Builder when we hover over view and fields.


Setup:

On your workstation, unzip the file in a folder of your choice
In Chrome or Edge:
	go in Manage Extensions
	enable Developer mode
	click on Load unpacked and select the folder where the unzipped files are located
	
Refresh your Builder pages
Start working without frustration!

Enjoy,
Normand D.
